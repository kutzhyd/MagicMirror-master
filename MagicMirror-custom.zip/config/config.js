/* Magic Mirror Config Sample
 *
 * By Michael Teeuw http://michaelteeuw.nl
 * MIT Licensed.
 */

var config = {
	port: 9091,

	language: 'en',
	timeFormat: 24,
	units: 'imperial',

	modules: [
	
	
	
	/*
	
	{
    module: 'MMM-Traffic',
    position: 'bottom_left',
    classes: 'dimmed medium', //optional, default is 'bright medium', only applies to commute info not route_name
    config: {
        api_key: 'AIzaSyBb-wKCqG7FraC5QGkHUaa5Tp-decKiQbM',
        mode: 'driving',
        origin: '303 W 3rd St, Reno, NV 89503',
        destination: '1 Electric Ave, Sparks, NV 89434',
        arrival_time: '0800', //optional, but needs to be in 24 hour time if used.
        route_name: 'Home to Work',
        changeColor: true,
        showGreen: true,
        limitYellow: 5, //Greater than 5% of journey time due to traffic
        limitRed: 10, //Greater than 10% of journey time due to traffic
        traffic_model: 'optimistic',
        interval: 120000 //2 minutes
    }
},
	
	
	*/
	
	
	
	


		{

    module: 'MMM-Scrobbler',

    position: 'right bottom',
    config: {

        username: 'kutzhyd',

        apikey: 'c3d46fe9b415d0da319550085d390bba',

        //time interval to search for new song (every 15 seconds)
        updateInterval: 1 * 1000,
        //how often should we try to retrieve a song if not listening
        delayCount: 5,
        //time interval to search for new song if the 5 times not listening is received.
        //set this to the same number as updateInterval to ignore this option   
        delayInterval: 12*1000,
        animationSpeed: 1000,
        }

},
		{
			module: 'alert',
		},
		{
			module: 'clock',
			position: 'top_left'
		},
	
//		{
//			module: 'compliments',
//			position: 'lower_third'
//		},
		{
			module: 'currentweather',
			position: 'top_right',
			config: {
				location: 'Sparks,NV',
				locationID: '5512862',  //ID from http://www.openweathermap.org
				appid: '619e9fdb595043638f7d251b22f0e0bc'
			}
		},
		{
			module: 'weatherforecast',
			position: 'top_right',
			header: 'Reno,NV',
			config: {
	            location: 'Sparks,NV',
				locationID: '5512862',  //ID from http://www.openweathermap.org
	            appid: '619e9fdb595043638f7d251b22f0e0bc'
			}
		},
		
		
		
		
		{
			module: 'newsfeed',
			position: 'bottom_bar',
			config: {
				feeds: [
					{
						title: "New York Times",
						url: "http://www.nytimes.com/services/xml/rss/nyt/HomePage.xml"
					}
				],
				showSourceTitle: true,
				showPublishDate: true
			}
		},
	]

};

/*************** DO NOT EDIT THE LINE BELOW ***************/
if (typeof module !== 'undefined') {module.exports = config;}
